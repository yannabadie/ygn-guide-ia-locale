# Kit « IA locale sur Mac » (octobre 2026)

Décompressez dans `~/ia-locale-kit`, puis : `chmod +x scripts/*.sh && ./scripts/check-mac.sh`

- scripts/check-mac.sh — puce, mémoire, disque, modèles conseillés
- scripts/installer.sh — vérifie/installe Ollama, ffmpeg, télécharge les modèles conseillés (demande confirmation)
- scripts/ia.sh — envoie stdin + consigne à Ollama (Raccourcis, Services)
- scripts/transcrire-et-resumer.sh — audio → transcription Whisper → compte rendu
- scripts/bench.sh — mesure la vitesse (tok/s) d'un modèle
- modelfiles/ — assistants personnalisés pour `ollama create`
- prompts/ — prompts métier en français
- rag/rag_local.py — RAG minimal 100 % local via l'API Ollama
- rgpd/ — checklist, fiche registre, charte d'usage

Tout s'exécute en local. Aucun script n'envoie de données hors de votre Mac (hors téléchargements de logiciels/modèles).

## Nouveautés v2 (31/10/2026)
- scripts/extraire_facture.py — facture texte → ligne CSV, avec contrôle HT + TVA = TTC
- exemples/ — 7 documents fictifs pour tester les 6 cas du chapitre 9 avant d'y mettre un vrai dossier
- mesure-gain.csv — tableau pour chronométrer le temps gagné
- transcrire-et-resumer.sh accepte désormais un prompt : `transcrire-et-resumer.sh audio.m4a compte-rendu-medical`
