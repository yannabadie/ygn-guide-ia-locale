# Checklist RGPD — IA locale (25 points)
Aide pratique, pas un avis juridique.
## Gouvernance
- [ ] 1. Finalités de l'usage de l'IA écrites
- [ ] 2. Fiche ajoutée au registre des traitements (art. 30)
- [ ] 3. Base légale identifiée pour chaque finalité
- [ ] 4. Personne référente désignée
- [ ] 5. Charte d'usage diffusée et signée/lue
- [ ] 6. Formation des utilisateurs tracée (AI Act art. 4)
- [ ] 7. Analyse d'impact (AIPD) évaluée si données sensibles à grande échelle
## Données
- [ ] 8. Minimisation : seules les données utiles sont fournies au modèle
- [ ] 9. Pseudonymisation quand c'est possible
- [ ] 10. Durées de conservation : historiques de discussion
- [ ] 11. Durées de conservation : transcriptions et audios
- [ ] 12. Durées de conservation : index RAG
- [ ] 13. Information des personnes (enregistrements, usage de l'IA)
- [ ] 14. Procédure pour les demandes d'accès/effacement (où sont les données ?)
## Technique
- [ ] 15. FileVault activé
- [ ] 16. Modèles exclusivement locaux (aucun modèle « cloud »)
- [ ] 17. Services en écoute sur 127.0.0.1 uniquement (ou réseau restreint)
- [ ] 18. Test « Wi-Fi coupé » réussi
- [ ] 19. Dossiers sensibles exclus de la synchronisation en ligne
- [ ] 20. Sauvegardes chiffrées
- [ ] 21. Mises à jour appliquées
- [ ] 22. Comptes individuels (serveur d'équipe)
- [ ] 23. Modèles téléchargés depuis des sources reconnues
## Usage
- [ ] 24. Relecture humaine obligatoire avant tout envoi/décision
- [ ] 25. Aucune décision produisant des effets juridiques fondée uniquement sur l'IA (art. 22)
