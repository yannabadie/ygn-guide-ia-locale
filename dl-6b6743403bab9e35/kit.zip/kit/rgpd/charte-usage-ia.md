# Charte d'usage de l'IA — [Nom de la structure] (modèle)
1. Seuls les outils d'IA **locaux** validés sont autorisés pour des données clients ou personnelles : [liste].
2. Interdit : copier des données clients, patients ou salariés dans un service d'IA en ligne non validé.
3. Toute production de l'IA est un **brouillon** : elle est relue, vérifiée (faits, dates, chiffres, références) et assumée par la personne qui l'utilise.
4. Aucune décision concernant une personne n'est prise sur la seule base d'un résultat d'IA.
5. Les personnes enregistrées sont informées avant toute transcription.
6. Les historiques, transcriptions et index sont supprimés selon les durées fixées : [..].
7. Tout incident (fuite, erreur grave) est signalé à : [référent].
Lu et approuvé — Nom, date, signature
