"""resumer_long.py transcription.txt prompt.md modèle — résumé map-reduce via Ollama local."""
import json, sys, urllib.request
def ia(p, m):
    d = json.dumps({"model": m, "prompt": p, "stream": False, "options": {"num_ctx": 16384}}).encode()
    r = urllib.request.Request("http://127.0.0.1:11434/api/generate", d, {"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(r, timeout=1800))["response"].strip()
txt, prompt, m = open(sys.argv[1]).read(), open(sys.argv[2]).read(), sys.argv[3]
mots = txt.split(); taille = 6000
blocs = [" ".join(mots[i:i+taille]) for i in range(0, len(mots), taille)] or [""]
if len(blocs) > 1:
    notes = [ia(f"Prends des notes détaillées (décisions, actions, chiffres, noms) sur cet extrait de réunion :\n\n{b}", m) for b in blocs]
    txt = "\n\n".join(notes)
print(ia(f"{prompt}\n\n---\n{txt}", m))
