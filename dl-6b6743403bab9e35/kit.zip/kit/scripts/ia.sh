#!/bin/bash
# ia.sh — usage : echo "texte" | ia.sh "Consigne" [modèle]
# Envoie consigne + texte (stdin) à l'API locale Ollama et affiche la réponse.
CONSIGNE="${1:-Réponds en français :}"; MODELE="${2:-${IA_MODELE:-assistant-fr}}"
TEXTE=$(cat)
python3 - "$CONSIGNE" "$MODELE" "$TEXTE" <<'PY'
import json, sys, urllib.request
c, m, t = sys.argv[1:4]
d = json.dumps({"model": m, "prompt": f"{c}\n\n{t}", "stream": False}).encode()
r = urllib.request.Request("http://127.0.0.1:11434/api/generate", d, {"Content-Type": "application/json"})
print(json.load(urllib.request.urlopen(r, timeout=600))["response"].strip())
PY
