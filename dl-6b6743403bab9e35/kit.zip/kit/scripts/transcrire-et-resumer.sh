#!/bin/bash
# transcrire-et-resumer.sh fichier_audio [prompt] [modèle_ollama]
# prompt = nom d'un fichier de prompts/ sans .md (défaut : compte-rendu ; ex. compte-rendu-medical)
# 1) ffmpeg -> WAV 16 kHz mono  2) whisper-cli (whisper.cpp) ou mlx_whisper  3) compte rendu via Ollama
# Variables : WHISPER_MODEL=chemin/ggml-large-v3-turbo.bin (whisper.cpp)
set -e
IN="$1"; P="${2:-compte-rendu}"; M="${3:-assistant-fr}"; [ -f "$IN" ] || { echo "usage: $0 audio [prompt] [modèle]"; exit 1; }
DIR="$(cd "$(dirname "$0")/.." && pwd)"; BASE="${IN%.*}"
ffmpeg -loglevel error -y -i "$IN" -ar 16000 -ac 1 -c:a pcm_s16le "$BASE.wav"
if command -v whisper-cli >/dev/null && [ -f "${WHISPER_MODEL:-}" ]; then
  whisper-cli -m "$WHISPER_MODEL" -l fr -f "$BASE.wav" -otxt -of "$BASE"
elif command -v mlx_whisper >/dev/null; then
  mlx_whisper "$BASE.wav" --model mlx-community/whisper-large-v3-turbo --language fr --output-format txt --output-dir "$(dirname "$IN")"
  mv "$(dirname "$IN")/$(basename "$BASE").txt" "$BASE.txt" 2>/dev/null || true
else echo "Installez whisper.cpp (et définissez WHISPER_MODEL) ou mlx-whisper."; exit 1; fi
echo "Transcription : $BASE.txt"
python3 "$DIR/scripts/resumer_long.py" "$BASE.txt" "$DIR/prompts/$P.md" "$M" > "$BASE.$P.md"
echo "Compte rendu  : $BASE.$P.md"
rm -f "$BASE.wav"
