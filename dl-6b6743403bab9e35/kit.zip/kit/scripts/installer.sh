#!/bin/bash
# installer.sh — installation guidée. Demande confirmation avant chaque étape.
set -e
ask(){ read -r -p "$1 [o/N] " r; [[ "$r" =~ ^[oOyY]$ ]]; }
cd "$(dirname "$0")"
./check-mac.sh || true
if ! command -v ollama >/dev/null; then
  if command -v brew >/dev/null && ask "Installer Ollama via Homebrew ?"; then brew install ollama; brew services start ollama;
  else echo "Téléchargez Ollama : https://ollama.com/download puis relancez ce script."; exit 1; fi
fi
command -v ffmpeg >/dev/null || { command -v brew >/dev/null && ask "Installer ffmpeg ?" && brew install ffmpeg; }
mem_gb=$(( $(sysctl -n hw.memsize) / 1073741824 ))
if (( mem_gb >= 24 )); then M=qwen3.6:35b; elif (( mem_gb >= 16 )); then M=gemma4:12b; else M=gemma4:e4b; fi
ask "Télécharger $M et bge-m3 ?" && { ollama pull "$M"; ollama pull bge-m3; }
if ask "Créer l'assistant 'assistant-fr' basé sur $M ?"; then
  sed "s/^FROM .*/FROM $M/" ../modelfiles/assistant-fr.Modelfile > /tmp/assistant-fr.Modelfile
  ollama create assistant-fr -f /tmp/assistant-fr.Modelfile
fi
echo "Terminé. Essayez : ollama run assistant-fr"
