#!/bin/bash
# bench.sh modèle — mesure la vitesse de génération (tok/s) via l'API Ollama.
M="${1:?usage: bench.sh modèle}"
curl -s http://127.0.0.1:11434/api/generate -d "{\"model\":\"$M\",\"prompt\":\"Explique en 200 mots ce qu'est le RGPD.\",\"stream\":false}" |
python3 -c "import json,sys;r=json.load(sys.stdin);print(f\"$M : {r['eval_count']/(r['eval_duration']/1e9):.1f} tok/s (génération), chargement {r.get('load_duration',0)/1e9:.1f} s\")"
