#!/bin/bash
# check-mac.sh — affiche puce, mémoire, disque libre et une recommandation de modèle.
set -e
chip=$(sysctl -n machdep.cpu.brand_string 2>/dev/null || echo "inconnu")
mem_gb=$(( $(sysctl -n hw.memsize) / 1073741824 ))
free_gb=$(df -g / | awk 'NR==2{print $4}')
echo "Puce      : $chip"
echo "Mémoire   : ${mem_gb} Go"
echo "Disque    : ${free_gb} Go libres"
echo "macOS     : $(sw_vers -productVersion)"
if [[ "$(uname -m)" != "arm64" ]]; then
  echo "⚠️  Mac Intel : ce guide vise les puces Apple (M1+). Petits modèles uniquement."; exit 0; fi
if   (( mem_gb >= 96 )); then rec="qwen3.6:35b (rapide) ou gpt-oss:120b ; qwen3.8:27b"
elif (( mem_gb >= 48 )); then rec="qwen3.6:35b ; qwen3.8:27b ; qwen3-coder:30b"
elif (( mem_gb >= 24 )); then rec="qwen3.6:35b ou gemma4:26b"
elif (( mem_gb >= 16 )); then rec="gemma4:12b ou gpt-oss:20b"
else rec="gemma4:e4b ou ministral-3:3b"; fi
echo "Conseillé : $rec  (+ bge-m3 pour les documents)"
(( free_gb < 40 )) && echo "⚠️  Moins de 40 Go libres : prévoyez de la place pour les modèles."
command -v ollama >/dev/null && echo "Ollama    : $(ollama --version 2>/dev/null | tail -1)" || echo "Ollama    : non installé (https://ollama.com/download)"
command -v ffmpeg >/dev/null && echo "ffmpeg    : présent" || echo "ffmpeg    : absent (brew install ffmpeg)"
