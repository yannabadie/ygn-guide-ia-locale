#!/usr/bin/env python3
"""extraire_facture.py fichier.txt [modèle] — extrait une facture (texte) en une ligne CSV
via la sortie structurée d'Ollama (JSON contraint), puis vérifie HT + TVA = TTC.
Sortie : numero;fournisseur;date;ht;tva;ttc[;ECART]"""
import json, sys, urllib.request
src = open(sys.argv[1], encoding="utf-8").read()
model = sys.argv[2] if len(sys.argv) > 2 else "gemma4:12b"
schema = {"type": "object", "properties": {
    "numero": {"type": "string"}, "fournisseur": {"type": "string"},
    "date": {"type": "string", "description": "AAAA-MM-JJ"},
    "ht": {"type": "number"}, "tva": {"type": "number"}, "ttc": {"type": "number"}},
    "required": ["numero", "fournisseur", "date", "ht", "tva", "ttc"]}
body = {"model": model, "stream": False, "format": schema, "options": {"temperature": 0},
        "messages": [{"role": "user", "content":
        "Extrais les champs de cette facture. Date au format AAAA-MM-JJ. Montants en nombres "
        "(point décimal). N'invente rien : chaîne vide si absent.\n\n" + src}]}
req = urllib.request.Request("http://127.0.0.1:11434/api/chat", json.dumps(body).encode(),
                             {"Content-Type": "application/json"})
d = json.loads(json.load(urllib.request.urlopen(req))["message"]["content"])
ok = abs(d["ht"] + d["tva"] - d["ttc"]) < 0.01
print(";".join([d["numero"], d["fournisseur"], d["date"], f'{d["ht"]:.2f}', f'{d["tva"]:.2f}',
                f'{d["ttc"]:.2f}'] + ([] if ok else ["ECART"])))
