#!/usr/bin/env python3
"""rag_local.py — RAG minimal 100 % local via l'API Ollama.
  python rag_local.py index DOSSIER     (indexe .txt .md .pdf)
  python rag_local.py ask "question"
Variables : EMBED_MODEL (bge-m3), CHAT_MODEL (gemma4:12b), INDEX (index.json)
Dépendance : pip install pypdf
"""
import json, math, os, sys, urllib.request
from pathlib import Path
OLLAMA = "http://127.0.0.1:11434"
EMB = os.environ.get("EMBED_MODEL", "bge-m3")
CHAT = os.environ.get("CHAT_MODEL", "gemma4:12b")
INDEX = Path(os.environ.get("INDEX", Path(__file__).with_name("index.json")))
TAILLE, CHEV = 400, 60  # mots par passage, chevauchement

def post(path, payload):
    req = urllib.request.Request(OLLAMA + path, json.dumps(payload).encode(), {"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(req, timeout=900))

def embed(textes):
    return post("/api/embed", {"model": EMB, "input": textes})["embeddings"]

def lire(p):
    if p.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        return "\n".join((pg.extract_text() or "") for pg in PdfReader(str(p)).pages)
    return p.read_text(errors="ignore")

def decouper(texte):
    mots = texte.split()
    for i in range(0, max(len(mots), 1), TAILLE - CHEV):
        bloc = " ".join(mots[i:i + TAILLE])
        if bloc.strip():
            yield bloc

def cos(a, b):
    s = sum(x * y for x, y in zip(a, b))
    return s / (math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b)) or 1)

def index(dossier):
    items = []
    for p in sorted(Path(dossier).expanduser().rglob("*")):
        if p.suffix.lower() not in {".txt", ".md", ".pdf"}:
            continue
        blocs = list(decouper(lire(p)))
        for i in range(0, len(blocs), 16):
            lot = blocs[i:i + 16]
            for b, v in zip(lot, embed(lot)):
                items.append({"source": p.name, "texte": b, "v": v})
        print(f"{p.name}: {len(blocs)} passages")
    INDEX.write_text(json.dumps({"modele": EMB, "items": items}))
    print(f"Index : {INDEX} ({len(items)} passages)")

def ask(question, k=5):
    data = json.loads(INDEX.read_text())
    q = embed([question])[0]
    top = sorted(data["items"], key=lambda it: cos(q, it["v"]), reverse=True)[:k]
    contexte = "\n\n".join(f"[{t['source']}]\n{t['texte']}" for t in top)
    prompt = ("Réponds en français uniquement à partir des extraits ci-dessous. Cite [fichier] après chaque "
              "affirmation. Si l'information n'y est pas, dis-le.\n\n"
              f"EXTRAITS :\n{contexte}\n\nQUESTION : {question}")
    r = post("/api/chat", {"model": CHAT, "stream": False, "messages": [{"role": "user", "content": prompt}]})
    print(r["message"]["content"].strip())
    print("\nSources consultées :", ", ".join(dict.fromkeys(t["source"] for t in top)))

if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] not in {"index", "ask"}:
        sys.exit(__doc__)
    index(sys.argv[2]) if sys.argv[1] == "index" else ask(" ".join(sys.argv[2:]))
