Rédige un courrier professionnel en français.
Expéditeur : [..] Destinataire : [..] Objet : [..] Ton : [courtois / ferme / pédagogique]
Éléments à inclure : [..]
Contraintes : une page maximum, phrases courtes, pas de formule creuse, aucune information non fournie ;
indique [À COMPLÉTER] là où une donnée manque.
