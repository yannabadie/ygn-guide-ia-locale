Compare la VERSION A et la VERSION B ci-dessous. Liste chaque différence de fond (pas la mise en forme) :
| Article/Clause | Version A | Version B | Portée de la modification |. Termine par les points à vérifier par un professionnel.
