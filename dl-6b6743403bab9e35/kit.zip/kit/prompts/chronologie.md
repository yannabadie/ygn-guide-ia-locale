À partir des documents ci-dessous, établis une chronologie des faits sous forme de tableau
| Date | Fait | Source (document, page/passage) |.
N'inclus que les dates explicitement présentes. Si une date est approximative, indique-le. Ne déduis rien.
