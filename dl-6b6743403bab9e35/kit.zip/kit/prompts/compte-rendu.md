Tu reçois la transcription (ou des notes) d'une réunion professionnelle. Rédige un compte rendu en français :
1. **Synthèse** (5 lignes maximum)
2. **Décisions prises** (liste)
3. **Actions** : tableau | Qui | Quoi | Échéance | (n'invente ni responsable ni échéance : écris « non attribué » ou « à préciser »)
4. **Points ouverts / questions**
N'ajoute aucune information absente de la transcription. Signale les passages inaudibles ou ambigus.
