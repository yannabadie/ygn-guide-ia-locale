Explique le passage suivant à un client non spécialiste : 5 phrases maximum, sans jargon,
puis une liste « Ce que cela change pour vous ». Ne donne pas d'avis : reformule fidèlement.
