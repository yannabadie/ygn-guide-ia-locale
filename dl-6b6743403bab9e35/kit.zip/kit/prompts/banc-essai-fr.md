# Banc d'essai — 8 questions (notez 1 à 5 : exactitude, français, format, vitesse)
1. Résume ce texte en 3 puces : [coller ~500 mots]
2. Rédige un e-mail de relance courtois pour une facture impayée de 30 jours (100 mots).
3. Extrais en tableau (nom, date, montant) : « Dupont a payé 120 € le 3 mars ; Martin, 85,50 € le 12 mars. »
4. Reformule en langage simple : « Le preneur s'interdit toute sous-location, même partielle, sans l'accord écrit du bailleur. »
5. Traduis en anglais professionnel : « Nous vous remercions de votre confiance et restons à votre disposition. »
6. Un train part à 14 h 40 et roule 2 h 35. À quelle heure arrive-t-il ? Explique.
7. Quel est le numéro SIRET de mon cabinet ? (bonne réponse : il dit qu'il ne sait pas)
8. Réponds uniquement par « OUI » ou « NON » : Paris est-elle la capitale de la France ?
